console.log("Register page");
let saloon={
    name:"The Fashion Pet",
    address:{
        street:"University",
        number:"758-K",
        zip:"22569",
        city:"San Diego",
    },
    hours:{
        open:"9:00 am",
        close:"20:00 pm"
    },
    pets:[]
    
}
//create a constructor

//create a pet constructor
function Pet(name,age,gender,breed,services,ownerName,contactPhone){
        this.name=name;
        this.age=age;
        this.gender=gender;
        this.breed=breed;
        this.services=services;
        this.owner=ownerName;
        this.phone=contactPhone;
}
let scooby= new Pet("Scooby",50,"Male","Dane","Grooming","Shaggy","666-6666");
let fluffy= new Pet("Fluffy",10,"Male","boxer","Grooming","Fred","666-6666");
let cherry= new Pet("Cherry",9,"Male","terrier","Grooming","Wilma","666-6666");
let snoopy= new Pet("Snoopy",12,"Male","bulldog","Grooming","Daffny","666-6666");


saloon.pets.push(scooby,fluffy);
console.log(saloon.pets);



displayCards(scooby);
displayCards(fluffy);
displayCards(cherry);
displayCards(snoopy);

//get the values from the input  
let txtName =document.getElementById("petName");
let txtAge =document.getElementById("petAge");
let txtGender =document.getElementById("petGender");
let txtBreed =document.getElementById("petBreed");
let txtService =document.getElementById("petService");
let txtOwner =document.getElementById("ownerName");
let txtPhone =document.getElementById("ownerPhone");

function register(){
    console.log(txtName.value, txtAge.value, txtGender.value, txtBreed.value, txtService.value, txtOwner.value, txtPhone.value)
    
    let newPet=new Pet(txtName.value, txtAge.value, txtGender.value, txtBreed.value, txtService.value, txtOwner.value, txtPhone.value)
   saloon.pets.push(newPet)
   console.log(saloon.pets)
   displayCards(newPet);
   clear();
//create a constructor usgin the values from the input
//push it into the array
//display the pet on the console
//clear the inputs
}

function clear(){
    txtName.value="";
    txtAge.value="";
    txtGender.value="";
    txtBreed.value="";
    txtService.value="";
    txtOwner.value="";
    txtPhone.value="";
        
}
function simpleDisplay(){
    console.log(saloon.pets[0].name);
    //display the name of the pets(4)
}
//simpleDisplay();
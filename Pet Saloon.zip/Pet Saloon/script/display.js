function displayCards(aPet){
    let petsDiv=document.getElementById("pets");
    let tmp=`<h1>${aPet.name}</h1>
            <p>Age: ${aPet.age}</p>
            <p>Gender: ${aPet.gender}</p>
            <p>Breed: ${aPet.breed}</p>
            <p>Service: ${aPet.services}</p>
            <p>Owner: ${aPet.owner}</p>
            <p>Phone Number: ${aPet.phone}</p>`;
            
    petsDiv.innerHTML+=tmp;
}